%% test code  for Scence 7

%% Xiongjun Zhang and Michael K. Ng. Low Rank Tensor Completion with Poisson Observations, 
%% IEEE Transactions on Pattern Analysis and Machine Intelligence, 
%% DOI: 10.1109/TPAMI.2021.3059299, 2021. 
%% For any questions, please contact: Xiongjun Zhang (email: xjzhang@mail.ccnu.edu.cn)


%%

clear all

randn('seed',2013); randn('seed',2013);

%% Scence 7 dataset
load('S7')

XT(XT<0) = 0; %% to aviod negative entry of XT

%% 
[n1 n2 n3] = size(XT);

sr = [0.3];     % sampling ratio

M = 100; %% peak value
c = 5;   %% fixed background
for jj = 1:length(sr)

%% generate Omega
fprintf('Sampling ratio = %0.8e\n',sr(jj));
temp = randperm(n1*n2*n3);
kks = round((sr(jj))*n1*n2*n3);
mark = zeros(n1,n2,n3); 
mark(temp(1:kks)) = 1;
% mark = logical(mark);

%% Observation
XT0 = XT*M; %% ground-truth data with peak value M
Xc = XT0 + c.*ones([n1 n2 n3]);
Y0 = poissrnd(Xc);
Y = Y0.*mark;  %% observed data

%% parameters
tol = 1e-4;  % stopping error
maxite = 500; % maximum iteration number
beta = M;  % maximum value of the ground-truth image
lambda = 0.06; 
tau = 1.618;
rho1 = 0.0005;
rho2 = 0.0005;

opts.tol = tol;
opts.maxite = maxite;   
opts.beta = beta;  
opts.c = c;
opts.lambda = lambda;
opts.tau = tau;
opts.rho1 = rho1;  
opts.rho2 = rho2;  


%% t-SVD (FFT)
 fprintf('t-SVD (FFT): \n');
tic;
[X  kmax] = PoiTNN(mark,Y,opts); %% Perform by FFT
toc;
        
SNRImFFT = SNR(X(:),XT0(:));
SSIMFFT = ssim3d(X/M*255,XT0/M*255);
fprintf('SNR = %0.4f      SSIM = %0.4f\n',SNRImFFT, SSIMFFT);
XEsti = X;  
  

%% t-SVD (DCT)
 fprintf('t-SVD (DCT): \n');
 
lambda = 0.5; 
rho1 = 0.005;
rho2 = 0.005;
opts.lambda = lambda;
opts.rho1 = rho1;  
opts.rho2 = rho2;  
     
tic;
[XDCT kmax1 eta1] = PoiDCTTNN(mark,Y,opts); %% Perform by FFT
toc;
    
SNRImDCT = SNR(XDCT(:),XT0(:));
SSIMDCT = ssim3d(XDCT/M*255,XT0/M*255);
fprintf('SNR = %0.4f      SSIM = %0.4f\n',SNRImDCT, SSIMDCT);
XEsti = XDCT;  
        
%% Unitary transformation t-SVD ��Data��       
fprintf('t-SVD (Data): \n');
O = tenmat(XEsti,[3]); % unfolding
O = O.data;
[U D V] = svd(O,'econ'); %% generate unitary matrix
clear D V
     
tic;
[XU kmax2 eta2] = PoiTTNN(U,mark,Y,opts);
toc;
   
SNRImU = SNR(XU(:),XT0(:));
SSIMU = ssim3d(XU*255/M,XT0*255/M);
fprintf('SNR = %0.4f      SSIM = %0.4f\n',SNRImU, SSIMU);

end

