function Y = Proj(X,a,b)

X(X<=a) = a;

X(X>=b) = b;

Y = X;