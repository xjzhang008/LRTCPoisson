function [X k ] = PoiTNN(mark,Y, opts)

%% ADMM for solving low-rank tensor completion with Poisson observations


if ~exist('opts', 'var')
    opts = [];
end    
if isfield(opts, 'tol');         tol = opts.tol;              end
if isfield(opts, 'beta');        beta = opts.beta;            end
if isfield(opts, 'c');           c = opts.c;                  end
if isfield(opts, 'maxite');      maxite = opts.maxite;        end
if isfield(opts, 'Z0');          Z0 = opts.Z0;                end
if isfield(opts, 'S0');          S0 = opts.S0;                end
if isfield(opts, 'M0');          M0 = opts.M0;                end
if isfield(opts, 'N0');          N0 = opts.N0;                end
if isfield(opts, 'lambda');      lambda = opts.lambda;        end
if isfield(opts, 'tau');         tau = opts.tau;              end
if isfield(opts, 'rho1');        rho1 = opts.rho1;            end
if isfield(opts, 'rho2');        rho2 = opts.rho2;            end

[n1 n2 n3] = size(Y); 
I = ones([n1,n2,n3]);
Barmark = ones(n1,n2,n3) - mark;    

Z0 = zeros([n1 n2 n3]);
S0 = Z0;
M0 = zeros([n1 n2 n3]);
N0 = M0;

for k = 1:maxite
   % update X
    X = prox_tnn((rho1*Z0 + rho2*S0 + M0 + N0)/(rho1 + rho2),1/(rho1 + rho2));
    
   % update Z,S
   ZA = (rho1*(X + c.*I) - (lambda.*I + M0) + sqrt((rho1.*(X + c.*I)-(lambda.*I + M0)).^2 + 4*lambda*rho1.*Y))./(2*rho1) - c.*I;
   Z = ZA.*mark + (X - M0./rho1).*Barmark;
   
   %% S
   S = Proj(X - N0./rho2,0,beta);
   
   % update the multipliers
   M = M0 + tau*rho1*(Z - X);
   N = N0 + tau*rho2*(S - X);
   
   
   %% stopping creterion
   if k >= 50
   etaz = (lambda.*I - (lambda.*Y)./(Z + c*I) + M).*mark + M.*Barmark;
   etaz = norm(etaz(:))/(1 + norm(M(:)));
   
   etas = S - Proj(S - N,0,beta);
   etas = norm(etas(:))/(1 + norm(S(:)) + norm(N(:)));
   
   etax = X - prox_tnn(M + N + X,1);
   etax = norm(etax(:))/(1+ norm(M(:)) + norm(N(:)) + norm(X(:)));
   
   etam = Z - X;
   etam = norm(etam(:))/(1+ norm(Z(:)) + norm(X(:)));
   
   etan = S - X;
   etan = norm(etan(:))/(1+ norm(S(:)) + norm(X(:)));
   
   eta = max([etaz, etas, etax, etam, etan]);
   if eta <= tol
         break;
   end
   end
   
   Z0 = Z;
   S0 = S;
   M0 = M;
   N0 = N;
   
    
end